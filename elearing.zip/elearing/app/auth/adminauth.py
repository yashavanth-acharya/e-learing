from functools import wraps
from django.shortcuts import redirect


def check_admin_login(func):
    @wraps(func)
    def inner(self,request, *args, **kwargs):

        if request.session.get("user") and request.session.get("role")=='admin':
            return func(self,request, *args, **kwargs)
        else:
            next_url = request.path_info
            # request.session['redirecturl']=next_url
            # return redirect("/")
            return func(self,request, *args, **kwargs)

    return inner