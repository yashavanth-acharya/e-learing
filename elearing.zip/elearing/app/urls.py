from django.urls import path
from .src.login import Login,Logout
from .src.users.home import Home
from .src.login import Login
from .src.singup import Singup
from .src.users.course import Course
from .src.users.topic import Topic

from .src.admin.dashboard import Dashboard
from .src.admin.course import Addcourse,Editcourses
from .src.admin.viewcourse import Viewcourse,getcourse,DeleteCourse
from .src.admin.topic import Addtopic,Edittopic
from .src.admin.viewtopic import Viewtopic,gettopic,DeleteTopic

from .src.admin.viewquestions import ViewAddedtopic,ViewNexth,Deletequestion
from .src.admin.addquestions import AddQuestions,Editquestions
from .src.admin.users import User,Getuser,changepassword
from .src.admin.status import CoursesStatus,TopicStatus
urlpatterns = [
    path('', Home.as_view()),
    path('login', Login.as_view()),
    path('singup', Singup.as_view()),
    path('Course', Course.as_view()),
    path('topic/<str:id>', Topic.as_view()),
    path('logout/', Logout.as_view()),

    #admin
    path('dashboard', Dashboard.as_view()),
    
    path('addcourse', Addcourse.as_view()),
    path('courses', Viewcourse.as_view()),
    path('getcourse', getcourse.as_view()),
    path('editcourse', Editcourses.as_view()),
    path('deletecourse', DeleteCourse.as_view()),

    path('addtopic', Addtopic.as_view()),
    path('topic', Viewtopic.as_view()),
    path('gettopic', gettopic.as_view()),
    path('edittopic', Edittopic.as_view()),
    path('deletetopic', DeleteTopic.as_view()),

    path('viewaddedtopic', ViewAddedtopic.as_view()),
    path('questions', ViewNexth.as_view()),
    path('addquestion', AddQuestions.as_view()),
    path('editquestion', Editquestions.as_view()),
    path('deletequestion', Deletequestion.as_view()),

    path('students', User.as_view()),
    path('getuser', Getuser.as_view()),
    path('coursestatus',CoursesStatus.as_view()),
    path('topicstatus',TopicStatus.as_view()),
    path('changepassword',changepassword.as_view())









]