
localStorage.removeItem("editicon")
function editcourse(id){
    $.ajax({
        url:"editcourse",
        method:"GET",
        data:{"couserid":id},
        success:function(data){
            if(data.error==0){
              console.log(data)
              $("#editname").val(data.data.coursename)
              $("#editdescriptions").val(data.data.course_description)
              if(data.data.icon){
                localStorage.setItem("editicon",data.data.icon)
              }
            }
        }
    })
} 




$("#updatecourse").click(function () {
$("#errormsg2").empty()
$("#msg").empty()
let name=$("#editname").val()
let descriptions=$("#editdescriptions").val()
let icon=$('#editimage')[0].files;
let error1=0,error2=0,error3=0

if(name.length==0){
$("#editcoursename-error").html("Course name is required *")
$("#editname").addClass("errorborder")
$("#editname-error").addClass("errorlable")
error1=1
}else{
$("#editcoursename-error").html(" ")
$("#editname").removeClass("errorborder")
$("#editname-error").removeClass("errorlable")
error1=0
}

if(descriptions.length==0){
$("#editcourse-description-error").html("Course descriptions is required *")
$("#editdescriptions").addClass("errorborder")
$("#editdescriptions-error").addClass("errorlable")
error2=1
}else{
    $("#editcourse-description-error").html(" ")
    $("#editdescriptions").removeClass("errorborder")
    $("#editdescriptions-error").removeClass("errorlable")
    error2=0
}

function base64icon(file){
    var reader = new FileReader();
    
    reader.onload = function () {
        base64String = reader.result  
        imageBase64Stringsep = base64String;
        base64image=imageBase64Stringsep
        localStorage.setItem("editicon",base64image)
        
    }
    reader.readAsDataURL(file)
    return localStorage.getItem("editicon");
   
}


if(icon.length!=0){

let fileExtension = ['jpeg', 'jpg', 'png', 'gif'];
if ($.inArray(String(icon[0].name).split('.').pop().toLowerCase(), fileExtension) == -1) {
    $("#editiconerror").html("<p style='color:red'>Only formats are allowed : "+fileExtension.join(', ')+"*</p>");
    error3=1
}
else
{
if(icon[0].size>1083743){
    $("#editiconerror").html("Image size should be less than 1MB*")
    $("#editimageUploaded").addClass("errorborder")
    $("#editicon-error").addClass("errorlable")
    error3=1
}else{
    $("#editiconerror").html(" ")
    $("#editimageUploaded").removeClass("errorborder")
    $("#editicon-error").removeClass("errorlable")
    error3=0
    iconimage=base64icon(icon[0])
}
}
}else{
    iconimage=localStorage.getItem("editicon");
}
 



if(error1==0 && error2==0 && error3==0){
   
    $.ajax({
        method: "POST",
        url:"editcourse",
        data:{"name":name,"descriptions":descriptions,"icons":iconimage},
        success: function(data){
            
            if(data.error==0){
                console.log(localStorage.getItem("editicon"))
                echo=`<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Done</strong> `+data.msg+`.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>`
                  $('#example').DataTable().ajax.reload();
                  $('#modal2').modal('toggle');
                  $("form").trigger('reset');
                  $("#msg").append(echo)
            }else{
                echo=`<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Done</strong> `+data.msg+`.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>`
                  $("#errormsg2").append(echo)

            }
            
            
           

        },
        error: function(message){
            echo=`<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Done</strong> `+data.msg+`.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>`
              $("#errormsg2").append(echo)
        }
    })
}
 })
