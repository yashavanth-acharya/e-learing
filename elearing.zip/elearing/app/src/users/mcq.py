import bcrypt
from  model.questions import Questions
from django.views.generic import TemplateView
from django.shortcuts import render
from django.shortcuts import redirect


class Mcq(TemplateView):
    def get(self,request,id):
        if 'user' in request.session:
            try:
               data=Questions.objects.filter(topicid=id)
            except Exception as e:
                print(e)
                data=[]

            return render("/mcq.html",data=data)
        else:
            return redirect("/")


    def Post(self,request,id):
        if 'user' in request.session:
            try:
               data=Questions.objects.filter(topicid=id)
            except Exception as e:
                print(e)
                data=[]

            return render("/mcq.html")
        else:
            return redirect("/")
            