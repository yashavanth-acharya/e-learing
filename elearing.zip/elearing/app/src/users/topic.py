import bcrypt
from app.model.course import Courses
from app.model.topic import Topics
from django.views.generic import TemplateView
from django.shortcuts import render
from django.shortcuts import redirect


class Topic(TemplateView):
    def get(self,request,id):
        try:
            data=Topics.objects.filter(courseid=id)
        except Exception as e:
            print(e)
            data=[]
        data={"data":data}
        return render(request,"user/topic.html",data)
       


class check_course_id(TemplateView):
    def post(self,request):
        courseid = request.POST['courseid']
        request.session['courseid'] =courseid
        try:
            if Courses.objects.get(courseid=courseid):
                return redirect("/topic")
        except Exception as e:
            print(e)


class check_topic_id(TemplateView):
    def post(self,request):
        topicid = request.POST['topicid']
        request.session['topicid']=topicid
        try:
            if Topics.objects.get(topicid=topicid):
                return redirect("/mcq")
        except Exception as e:
            print(e)