from django.views.generic import TemplateView
from django.shortcuts import render
from django.shortcuts import redirect
from model.result import Result

class Result(TemplateView):
    def get(self,request):
        if 'user' in request.session:
            try:
               data=Result.objects.filter(userid=request.session['user'])
            except Exception as e:
                print(e)
                data=[]

            return render("/Results.html",data=data)
        else:
            return redirect("/")
            