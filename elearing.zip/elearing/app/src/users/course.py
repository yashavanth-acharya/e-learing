from app.model.course import Courses
from django.views.generic import TemplateView
from django.shortcuts import render
from django.shortcuts import redirect


class Course(TemplateView):
    def get(self,request):        
        return render(request,"user/Courses.html")
            