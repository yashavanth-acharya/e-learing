from model.result import Result
from django.views.generic import TemplateView
from django.shortcuts import render
from django.shortcuts import redirect

class Addcourse(TemplateView):
    def get(self,request):
        if 'admin' in request.session:
            return render("/admin/viewstudentresult.html")
        else:
            return redirect("/")