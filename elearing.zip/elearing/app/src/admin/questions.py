





# class viewquestions(TemplateView):
#     def get(self,request):

#         if Topics.objects.all():
#             return render("adminfolder/addquestions.html",msg="")
#         else:
#             return render("adminfolder/addquestions.html",msg={"msg": "There is no topic available"})
