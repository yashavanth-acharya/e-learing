
from app.model.user import Userdetails
from django.views.generic import TemplateView
from django.shortcuts import render
from django.shortcuts import redirect
from django.http import JsonResponse
import re
import bcrypt
regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
regex2 = "^[1-9]{1}[0-9]{2}\\s{0, 1}[0-9]{3}$"

class Singup(TemplateView):
    def get(self,request):
        msg={'msg':""}
        return render(request,"signup.html",msg)

    def post(self,request):
        username=request.POST['username']
        name = request.POST['name']
        lastname =request.POST['lastname']
        gender=request.POST['gender']
        email =request.POST['email']
        mobile= request.POST['mobile']
        date_of_birth =request.POST['date_of_birth']
        address = request.POST['address']
        city= request.POST['city']
        state= request.POST['state']
        pincode=request.POST['pincode']
        password= request.POST['password']
      
        if len(name)==0 or len(username)==0 or len(gender)==0 or len(pincode) or len(mobile)==0 or len(email) or \
        len(date_of_birth)==0 or len(address)==0 or len(city)==0 or len(state)==0 or len(password)==0:
            return JsonResponse({'data':"Given fielda is required *","error":1})

        if username.isalnum() == False:
            return JsonResponse({'data':"Username required alphanumeric characters, without symbols","error":1})

        if(re.match(regex, email)) == None:
            return JsonResponse({'data':"Enter valid email address","error":1})
        
        if(re.match(regex2, pincode)) == None:
            return JsonResponse({'data':"Enter valid pincode","error":1})

        if len(password)>32 or len(password)<8:
            return JsonResponse({'data':"Password lenght sholud be between 8 or 32","error":1})

        try:
            Userdetails.create(
                username =username,
                name = name,
                lastname = lastname,
                gender= gender,
                email = email,
                mobile= mobile,
                date_of_birth = date_of_birth,  
                address = address,
                city= city,
                state= state,
                pincode=pincode,
                password=str(bcrypt.hashpw(password, bcrypt.gensalt()))
            )
    
            return render("login.html",mgs="Account created successfully",error=0)
        except Exception as e:
            print(e)
            return JsonResponse({'data':"Server error","error":1})
        
