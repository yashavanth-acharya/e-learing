from os import error
import bcrypt
from ..model.user import Userdetails
from django.views.generic import TemplateView
from django.shortcuts import render
from django.shortcuts import redirect
from django.views import View

class Login(TemplateView):
    def get(self,request):
        msg={"msg":"","error":0}
        return render(request,"login.html",msg)

    def post(self,request):
        username=request.POST['username']
        password=request.POST['password']
        username=Userdetails.objects.get(username=username)
        if username:
            if bcrypt.checkpw(password, username.password):
                if username.user_role =="user":
                    request.session['user']=username.userid
                    return redirect("/home")
                else:
                    request.session['admin']=username.userid
                    return redirect("/dashboard")
        msg={"msg":"Invalid username or password","error":1}   
        return render(request,"login.html",msg)


class Logout(View):
    def get(self,request):
        request.session.clear()
        return redirect("/")

