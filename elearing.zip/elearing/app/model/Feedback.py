from django.db import models
import uuid

class Feedback(models.Model):
    Feedbackid = models.UUIDField(primary_key = True,default = uuid.uuid4,editable = False)
    user = models.UUIDField()
    Feedback =models.CharField(max_length=200,unique=True)
    create_At=models.DateTimeField(auto_now_add=True)
