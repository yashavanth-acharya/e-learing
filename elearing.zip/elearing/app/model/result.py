from django.db import models
import uuid
from .user import Userdetails

class Result(models.Model):
    Resultid = models.UUIDField(primary_key = True,default = uuid.uuid4,editable = False)
    userid=models.ForeignKey(Userdetails, on_delete=models.CASCADE)
    totalmark = models.CharField(max_length=200)
    outof= models.CharField(max_length=200,)
    submitted_time = models.DateTimeField()
    create_At=models.DateTimeField(auto_now_add=True)
    updated_At=models.DateTimeField(auto_now=True)

