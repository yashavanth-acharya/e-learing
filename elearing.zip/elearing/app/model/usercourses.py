from django.db import models
import uuid

class Usercourse(models.Model):
    userid = models.UUIDField()
    coursename =models.CharField(max_length=100)
    topicname = models.CharField(max_length=200)
    joindate= models.CharField(max_length=200)
    status = models.DateTimeField()
    create_At=models.DateTimeField(auto_now_add=True)
    updated_At=models.DateTimeField(auto_now=True)
