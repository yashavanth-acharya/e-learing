from app.model.course import Courses
from app.model.Feedback import Feedback
from app.model.questions import Questions
from app.model.user import Userdetails
from app.model.result import Result
from app.model.topic import Topics
from app.model.usercourses import Usercourse
# Create your models here.
