run this command
python -m pip install -r requirements.txt
